
"use strict";
var builder = require("botbuilder");
var botbuilder_azure = require("botbuilder-azure");
var path = require('path');

var useEmulator = (process.env.NODE_ENV == 'development');

var connector = useEmulator ? new builder.ChatConnector() : new botbuilder_azure.BotServiceConnector({
    appId: process.env['MicrosoftAppId'],
    appPassword: process.env['MicrosoftAppPassword'],
    stateEndpoint: process.env['BotStateEndpoint'],
    openIdMetadata: process.env['BotOpenIdMetadata']
});

var bot = new builder.UniversalBot(connector);
bot.localePath(path.join(__dirname, './locale'));

// Make sure you add code to validate these fields
var luisAppId = process.env.LuisAppId;
var luisAPIKey = process.env.LuisAPIKey;
var luisAPIHostName = process.env.LuisAPIHostName || 'westus.api.cognitive.microsoft.com';

const LuisModelUrl = 'https://' + luisAPIHostName + '/luis/v1/application?id=' + luisAppId + '&subscription-key=' + luisAPIKey;

// Main dialog with LUIS
var recognizer = new builder.LuisRecognizer(LuisModelUrl);
var intents = new builder.IntentDialog({ recognizers: [recognizer] })


.matches('welcome', [
    function (session) {
        session.send('Well hello there, what can I help you with today?');
    },
    function (session, results) {
        if(results.response == 'incident') {
            session.beginDialog('submit ticket');
        } else  {
            session.beginDialog('error');
        }
    }
])
// .triggerAction({
//     matches: /^incident/i,
//     onSelectAction: (session, args, next) => {
//         // Add the help dialog to the dialog stack 
//         // (override the default behavior of replacing the stack)
//         session.beginDialog('submit ticket');
//     }
// });
// .triggerAction({
//     matches: 'welcome',
//     onInterrupted: function (session) {
//         session.send('Still want to create an Incident?');
//     }
// })

.matches('submit ticket', [
    function (session) {
        builder.Prompts.text(session, 'Lets start by getting your SSO?');
    },
    function (session, results) {
        session.dialogData.user = results.response;
        builder.Prompts.text(session, 'What would you like to put as the short description?');
        
    },
    function (session, results) {
        session.dialogData.shortdescription = results.response;
        builder.Prompts.text(session, 'Thanks, what about a more detailed description of the issue?');
        
    },
    function (session, results) {
        session.dialogData.longdescription = results.response;
        builder.Prompts.text(session, 'What person would you like to assign this to?');
        
    },
    function (session, results) {
        session.dialogData.assign = results.response;
        builder.Prompts.text(session, 'What assignment group would you like to assign this to? An example would be "@Digital sn geit itil users"');
        
    },
    function (session, results) {
        session.dialogData.assigngroup = results.response;
        builder.Prompts.text(session, 'Last but not least, What would you like to put as the Business Service? An example would be "geit.service-now.com"');
        
    },
    function (session, results) {
        session.dialogData.busservice = results.response;
        var message = 'That was perfect, I went ahead and created an Incident in ServiceNow with short decscription of';
        message += ' "%s"...now that will be $5.00 please';

        session.send(message, session.dialogData.shortdescription, session.dialogData.user, session.dialogData.longdescription, session.dialogData.assign, session.dialogData.assigngroup, session.dialogData.busservice);
        var data = {
        'caller_id' : session.dialogData.user,
        'short_description' : session.dialogData.shortdescription,
        'description' : session.dialogData.longdescription,
        'assigned_to': session.dialogData.assign,
        'assignment_group' : session.dialogData.assigngroup,
        'business_service' : session.dialogData.busservice
    }

    // Async search
    var http = require('https');

    var post_req  = null;
    var post_data = JSON.stringify(data);
    
    var post_options = {
        hostname: 'geitsandbox.service-now.com',
        path: '/api/now/table/incident?sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_input_display_value=true',
        method  : 'POST',
        headers : {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Basic MjEyNjE0MTE2OndpbGxpbmdoYW0='
            
        }
    };
    
    post_req = http.request(post_options, function (res) {
        console.info('STATUS: ' + res.statusCode);
        console.info('HEADERS: ' + JSON.stringify(res.headers));
        res.on('data', function (chunk) {
            console.info('Response: ', chunk);
        });
    });
    
    post_req.on('error', function(e) {
        console.info('problem with request: ' + e.message);
    });
    
    post_req.write(post_data);
    session.send('Just kidding about the money, have a great day!');
    post_req.end();
    }
]).triggerAction({
    matches: 'welcome',
    onInterrupted: function (session) {
        session.send('Still want to create an Incident?');
    }
})
.matches('error', (session, arg) =>{
    session.send("Sorry I can't do that yet...will be coming soon though!");
    
})

.onDefault((session) => {
    session.send('Sorry, I did not understand \'%s\'.', session.message.text);
});

bot.dialog('/', intents);    

if (useEmulator) {
    var restify = require('restify');
    var server = restify.createServer();
    server.listen(3978, function() {
        console.log('test bot endpont at http://localhost:3978/api/messages');
    });
    server.post('/api/messages', connector.listen());    
} else {
    module.exports = { default: connector.listen() }
}

